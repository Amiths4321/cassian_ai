import os
import uuid
import json
from contextlib import asynccontextmanager
from fastapi import Body
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from app.db_models import (
    Contract,
    DocumentChunk,
    ContractAnalysis,
    ContractRisk,
    ContractTerm,
)
from app.db_models import ContractCommercialDetail
from app.term_extraction import extract_contract_terms
import fitz
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from pgvector.sqlalchemy import Vector

from app.database import AsyncSessionLocal, init_db, close_db

from app.analysis_engine import analyse_contract

load_dotenv()

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
CHAT_MODEL = os.getenv("CHAT_MODEL", "llama3.2:latest")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text:latest")
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "http://localhost:3000")

DOCUMENTS_DIR = Path(__file__).resolve().parent.parent / "documents"
DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_CHAT_PROMPT = (
    "You are ContractIQ AI, a careful commercial contract analyst. "
    "Explain contract concepts clearly. Do not invent contract wording, "
    "dates, amounts or obligations. If no contract evidence is provided, "
    "say you are giving general information. Do not present your response "
    "as legal advice."
)

DOCUMENT_QA_PROMPT = """
You are ContractIQ AI, an expert commercial contract intelligence assistant.

Inspect all supplied contract evidence before answering.

Rules:
1. Search every supplied passage for information relevant to the question.
2. Extract exact amounts, dates, names, percentages and contractual periods.
3. Do not say information is missing if it appears in the evidence.
4. Do not confuse a liability cap with the contract value.
5. Distinguish contract fees from taxes and other potential obligations.
6. If the answer is genuinely absent, say:
   "This information is not specified in the provided contract."
7. Cite the relevant section and page number.
8. Never invent contractual terms.
9. Do not provide legal advice.

Answer format:
Answer: Give the direct answer first.
Explanation: Briefly explain the contractual provision.
Evidence: Quote the relevant contract wording.
Source: State the section and page number.
""".strip()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield
    await close_db()


app = FastAPI(
    title="ContractIQ AI Backend",
    version="0.4.0",
    description="Local contract intelligence powered by Ollama and PostgreSQL.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_ORIGIN, "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    system_prompt: Optional[str] = None

class ReviewRiskRequest(BaseModel):
    review_status: str = Field(min_length=1, max_length=30)
    review_notes: Optional[str] = Field(
        default=None,
        max_length=5000
    )

class EmbedRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)


class IndexRequest(BaseModel):
    filename: str = Field(min_length=1, max_length=255)


class DocumentAskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=12000)


async def ollama_get(path: str):
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.get(f"{OLLAMA_BASE_URL}{path}")
            response.raise_for_status()
            return response.json()
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail=f"Cannot reach Ollama: {exc}")


async def ollama_post(path: str, payload: dict, timeout: float = 180.0):
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{OLLAMA_BASE_URL}{path}",
                json=payload,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Ollama error: {exc.response.text[:1000]}",
        )
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail=f"Cannot reach Ollama: {exc}")


async def create_embedding(text: str):
    result = await ollama_post(
        "/api/embed",
        {"model": EMBED_MODEL, "input": text},
        timeout=120.0,
    )
    vectors = result.get("embeddings", [])
    if not vectors:
        raise HTTPException(status_code=502, detail="Embedding model returned no vector.")

    vector = vectors[0]
    if len(vector) != 768:
        raise HTTPException(
            status_code=502,
            detail=f"Expected 768 embedding dimensions, received {len(vector)}.",
        )
    return vector


def split_text(text: str, chunk_size: int = 1200, overlap: int = 150):
    text = " ".join(text.split())
    if len(text) <= chunk_size:
        return [text] if text else []

    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks


async def index_pdf_into_database(
    pdf_path: Path,
    stored_filename: str,
    original_filename: str,
):
    try:
        pdf = fitz.open(str(pdf_path))
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Could not read PDF: {exc}")

    chunks_to_save = []
    pages_with_text = set()
    try:
        for page_number, page in enumerate(pdf, start=1):
            page_text = page.get_text("text").strip()
            if not page_text:
                continue
            page_chunks = split_text(page_text)
            if page_chunks:
                pages_with_text.add(page_number)
            for part in page_chunks:
                vector = await create_embedding(part)
                chunks_to_save.append({
                    "page_number": page_number,
                    "chunk_text": part,
                    "embedding": vector,
                })
    finally:
        pdf.close()

    if not chunks_to_save:
        raise HTTPException(
            status_code=422,
            detail="No selectable text was found in this PDF. It may be scanned and require OCR.",
        )

    async with AsyncSessionLocal() as session:
        contract = Contract(
            filename=stored_filename,
            original_filename=original_filename,
            status="indexed",
            pages_indexed=len(pages_with_text),
            chunks_created=len(chunks_to_save),
        )
        session.add(contract)
        await session.flush()

        for chunk in chunks_to_save:
            session.add(DocumentChunk(
                contract_id=contract.id,
                page_number=chunk["page_number"],
                chunk_text=chunk["chunk_text"],
                embedding=chunk["embedding"],
            ))

        await session.commit()
        await session.refresh(contract)
        return {
            "message": "PDF indexed successfully.",
            "document_id": contract.id,
            "filename": contract.filename,
            "original_filename": contract.original_filename,
            "pages_indexed": contract.pages_indexed,
            "chunks_created": contract.chunks_created,
            "status": contract.status,
        }


@app.get("/")
async def root():
    return {"name": "ContractIQ AI Backend", "version": "0.4.0", "status": "running"}


@app.get("/api/health")
async def health():
    tags = await ollama_get("/api/tags")
    installed = {model.get("name") for model in tags.get("models", [])}
    async with AsyncSessionLocal() as session:
        count = await session.execute(select(func.count()).select_from(Contract))
        document_count = count.scalar_one()

    return {
        "api": "ok",
        "ollama": "connected",
        "chat_model": CHAT_MODEL,
        "chat_model_installed": CHAT_MODEL in installed,
        "embedding_model": EMBED_MODEL,
        "embedding_model_installed": EMBED_MODEL in installed,
        "indexed_documents": document_count,
        "database": "connected",
    }

@app.get("/api/gpu-status")
async def gpu_status():
    try:
        result = await ollama_get("/api/ps")
        models = result.get("models", [])

        if not models:
            return {
                "status": "idle",
                "model_loaded": False,
                "model": None,
                "size_vram": 0,
                "message": "No model is currently loaded."
            }

        model = models[0]
        size_vram = model.get("size_vram", 0)

        return {
            "status": "gpu_memory_allocated" if size_vram > 0 else "cpu_only",
            "model_loaded": True,
            "model": model.get("name"),
            "size_vram": size_vram,
            "size": model.get("size", 0),
            "message": (
                "Model memory is allocated on GPU."
                if size_vram > 0
                else "Model is loaded, but GPU memory allocation is not reported."
            )
        }

    except HTTPException:
        return {
            "status": "unavailable",
            "model_loaded": False,
            "model": None,
            "size_vram": 0,
            "message": "Cannot retrieve GPU status from Ollama."
        }

@app.post("/api/chat")
async def chat(request: ChatRequest):
    result = await ollama_post(
        "/api/chat",
        {
            "model": CHAT_MODEL,
            "messages": [
                {"role": "system", "content": request.system_prompt or DEFAULT_CHAT_PROMPT},
                {"role": "user", "content": request.message},
            ],
            "stream": False,
        },
    )
    return {
        "model": result.get("model", CHAT_MODEL),
        "response": result.get("message", {}).get("content", ""),
        "done": result.get("done", True),
    }


@app.post("/api/embed")
async def embed(request: EmbedRequest):
    vector = await create_embedding(request.text)
    return {"model": EMBED_MODEL, "dimensions": len(vector), "embedding": vector}


@app.post("/api/documents/index-local")
async def index_local_document(request: IndexRequest):
    filename = Path(request.filename).name
    if filename != request.filename:
        raise HTTPException(status_code=400, detail="Please provide only the PDF filename.")
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    pdf_path = DOCUMENTS_DIR / filename
    if not pdf_path.is_file():
        raise HTTPException(status_code=404, detail=f"PDF not found in documents folder: {filename}")

    return await index_pdf_into_database(pdf_path, filename, filename)


@app.post("/api/documents/upload")
async def upload_document(file: UploadFile = File(...)):
    original_name = Path(file.filename or "").name
    if not original_name.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    content = await file.read()
    if not content.startswith(b"%PDF-"):
        raise HTTPException(status_code=400, detail="The uploaded file is not a valid PDF.")

    if len(content) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="PDF exceeds the 20 MB upload limit.")

    safe_name = Path(original_name).stem[:100]
    stored_name = f"{uuid.uuid4().hex}_{safe_name}.pdf"
    destination = DOCUMENTS_DIR / stored_name

    try:
        destination.write_bytes(content)
        return {
            "message": "Contract uploaded and indexed successfully.",
            **await index_pdf_into_database(destination, stored_name, original_name),
        }
    except Exception:
        if destination.exists():
            destination.unlink()
        raise
    finally:
        await file.close()


@app.get("/api/documents")
async def list_documents():
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Contract).order_by(Contract.created_at.desc()))
        contracts = result.scalars().all()

    documents = [{
        "document_id": contract.id,
        "filename": contract.filename,
        "original_filename": contract.original_filename,
        "pages": contract.pages_indexed,
        "chunks": contract.chunks_created,
        "status": contract.status,
        "created_at": contract.created_at.isoformat() if contract.created_at else None,
    } for contract in contracts]

    return {"total": len(documents), "documents": documents}


@app.post("/api/documents/{document_id}/ask")
async def ask_document(document_id: str, request: DocumentAskRequest):
    async with AsyncSessionLocal() as session:
        contract_result = await session.execute(
            select(Contract).where(Contract.id == document_id)
        )
        contract = contract_result.scalar_one_or_none()
        if contract is None:
            raise HTTPException(
                status_code=404,
                detail="Document not found. Please upload or index it again.",
            )

        query_vector = await create_embedding(request.question)
        distance = DocumentChunk.embedding.cosine_distance(query_vector)
        chunk_result = await session.execute(
            select(DocumentChunk, distance.label("distance"))
            .where(DocumentChunk.contract_id == document_id)
            .order_by(distance)
            .limit(4)
        )
        retrieved = chunk_result.all()

        # Copy values before the session closes.
        filename = contract.original_filename
        selected_chunks = [
            (chunk.page_number, chunk.chunk_text, float(distance_value))
            for chunk, distance_value in retrieved
        ]

    if not selected_chunks:
        raise HTTPException(status_code=404, detail="No indexed text chunks were found for this contract.")

    context_parts = []
    sources = []
    for page_number, chunk_text, distance_value in selected_chunks:
        similarity = max(0.0, min(1.0, 1.0 - distance_value))
        context_parts.append(f"[Page {page_number}]\n{chunk_text}")
        sources.append({
            "page": page_number,
            "text": chunk_text,
            "similarity": round(similarity, 4),
        })

    result = await ollama_post(
        "/api/chat",
        {
            "model": CHAT_MODEL,
            "messages": [
                {"role": "system", "content": DOCUMENT_QA_PROMPT},
                {
                    "role": "user",
                    "content": (
                        f"Contract filename: {filename}\n\n"
                        f"Contract evidence:\n{'\n\n'.join(context_parts)}\n\n"
                        f"Question: {request.question}"
                    ),
                },
            ],
            "stream": False,
            "options": {"temperature": 0, "num_ctx": 8192},
        },
    )

    return {
        "document_id": document_id,
        "filename": filename,
        "model": CHAT_MODEL,
        "question": request.question,
        "answer": result.get("message", {}).get("content", ""),
        "sources": sources,
    }






@app.post("/api/documents/{document_id}/analyse")
async def analyse_document(document_id: str):
    """
    Analyse a complete stored contract, save the analysis,
    and persist individual risk findings.
    """

    async with AsyncSessionLocal() as session:
        contract_result = await session.execute(
            select(Contract).where(Contract.id == document_id)
        )
        contract = contract_result.scalar_one_or_none()

        if contract is None:
            raise HTTPException(
                status_code=404,
                detail="Contract not found."
            )

        chunks_result = await session.execute(
            select(DocumentChunk)
            .where(DocumentChunk.contract_id == document_id)
            .order_by(
                DocumentChunk.page_number,
                DocumentChunk.id
            )
        )

        chunks = chunks_result.scalars().all()

        if not chunks:
            raise HTTPException(
                status_code=404,
                detail="No indexed contract text was found."
            )

        contract_text = "\n\n".join(
            f"[Page {chunk.page_number}]\n{chunk.chunk_text}"
            for chunk in chunks
        )

        filename = contract.original_filename

        try:
            analysis = await analyse_contract(contract_text)

        except Exception as exc:
            import traceback

            traceback.print_exc()

            raise HTTPException(
                status_code=502,
                detail=f"Contract analysis failed: {type(exc).__name__}: {exc}"
            ) from exc

        # Save the complete analysis first.
        saved_analysis = ContractAnalysis(
            contract_id=document_id,
            analysis_type="full_contract",
            result=analysis,
        )

        session.add(saved_analysis)

        # Generate the analysis ID before saving linked risks.
        await session.flush()

        # Save each valid risk as an independent database record.
        risk_items = analysis.get("risk_assessment", [])
        saved_risk_count = 0

        valid_severities = {"low", "medium", "high"}

        for item in risk_items:
            if not isinstance(item, dict):
                continue

            risk = item.get("risk")
            explanation = item.get("explanation")
            evidence = item.get("evidence")

            if not all(
                isinstance(value, str) and value.strip()
                for value in [risk, explanation, evidence]
            ):
                continue

            severity = str(
                item.get("severity", "medium")
            ).lower()

            if severity not in valid_severities:
                severity = "medium"

            page_number = item.get("page_number")

            if not isinstance(page_number, int):
                page_number = None

            session.add(
                ContractRisk(
                    contract_id=document_id,
                    analysis_id=saved_analysis.id,
                    risk=risk.strip(),
                    severity=severity,
                    explanation=explanation.strip(),
                    evidence=evidence.strip(),
                    page_number=page_number,
                    review_status="pending",
                )
            )

            saved_risk_count += 1

        # Save the analysis and its risks together.
        await session.commit()
        await session.refresh(saved_analysis)

        return {
            "message": "Contract analysed and saved successfully.",
            "document_id": document_id,
            "filename": filename,
            "analysis_id": saved_analysis.id,
            "analysis_type": saved_analysis.analysis_type,
            "analysis": saved_analysis.result,
            "risks_saved": saved_risk_count,
            "created_at": (
                saved_analysis.created_at.isoformat()
                if saved_analysis.created_at else None
            ),
        }


@app.get("/api/documents/{document_id}/risks")
async def get_document_risks(document_id: str):
    """
    Retrieve risk findings from the latest contract analysis.
    """

    async with AsyncSessionLocal() as session:
        contract_result = await session.execute(
            select(Contract).where(Contract.id == document_id)
        )

        contract = contract_result.scalar_one_or_none()

        if contract is None:
            raise HTTPException(
                status_code=404,
                detail="Contract not found."
            )

        analysis_result = await session.execute(
            select(ContractAnalysis)
            .where(ContractAnalysis.contract_id == document_id)
            .order_by(
                ContractAnalysis.created_at.desc(),
                ContractAnalysis.id.desc()
            )
            .limit(1)
        )

        latest_analysis = analysis_result.scalar_one_or_none()

        if latest_analysis is None:
            raise HTTPException(
                status_code=404,
                detail="No analysis has been saved for this contract."
            )

        risks_result = await session.execute(
            select(ContractRisk)
            .where(
                ContractRisk.analysis_id == latest_analysis.id
            )
            .order_by(ContractRisk.id)
        )

        risks = risks_result.scalars().all()

        return {
            "document_id": document_id,
            "analysis_id": latest_analysis.id,
            "total_risks": len(risks),
            "risks": [
                {
                    "id": risk.id,
                    "risk": risk.risk,
                    "severity": risk.severity,
                    "explanation": risk.explanation,
                    "evidence": risk.evidence,
                    "page_number": risk.page_number,
                    "review_status": risk.review_status,
                    "review_notes": risk.review_notes,
                    "created_at": (
                        risk.created_at.isoformat()
                        if risk.created_at else None
                    ),
                    "reviewed_at": (
                        risk.reviewed_at.isoformat()
                        if risk.reviewed_at else None
                    ),
                }
                for risk in risks
            ],
        }


@app.patch("/api/documents/{document_id}/risks/{risk_id}/review")
async def update_risk_review(
    document_id: str,
    risk_id: int,
    request: ReviewRiskRequest,
):
    """Update the review status and notes for a contract risk."""

    allowed_statuses = {"pending", "reviewed", "resolved"}

    if request.review_status not in allowed_statuses:
        raise HTTPException(
            status_code=400,
            detail="Status must be pending, reviewed, or resolved."
        )

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractRisk).where(
                ContractRisk.id == risk_id,
                ContractRisk.contract_id == document_id,
            )
        )

        risk = result.scalar_one_or_none()

        if risk is None:
            raise HTTPException(
                status_code=404,
                detail="Risk finding not found for this contract."
            )

        risk.review_status = request.review_status
        risk.review_notes = request.review_notes

        if request.review_status == "pending":
            risk.reviewed_at = None
        else:
            risk.reviewed_at = func.now()

        await session.commit()
        await session.refresh(risk)

        return {
            "message": "Risk review updated successfully.",
            "id": risk.id,
            "review_status": risk.review_status,
            "review_notes": risk.review_notes,
            "reviewed_at": (
                risk.reviewed_at.isoformat()
                if risk.reviewed_at else None
            ),
        }

@app.post("/api/documents/{document_id}/extract-terms")
async def extract_document_terms(document_id: str):
    try:
        return await extract_contract_terms(document_id)

    except ValueError as exc:
        raise HTTPException(
            status_code=404,
            detail=str(exc),
        ) from exc

    except httpx.HTTPError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Contract extraction service failed: {exc}",
        ) from exc

    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=502,
            detail="The AI returned invalid extraction JSON.",
        ) from exc

@app.get("/api/documents/{document_id}/terms")
async def get_contract_terms(document_id: str):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractTerm)
            .where(ContractTerm.contract_id == document_id)
            .order_by(ContractTerm.page_number, ContractTerm.id)
        )

        terms = result.scalars().all()

        detail_result = await session.execute(
            select(ContractCommercialDetail).where(
                ContractCommercialDetail.term_id.in_(
                    [term.id for term in terms]
                )
            )
        )
        commercial_details_by_term = {
            detail.term_id: detail
            for detail in detail_result.scalars().all()
        }

        return {
            "document_id": document_id,
            "total_terms": len(terms),
            "terms": [
                {
                    "id": term.id,
                    "term_category": term.term_category,
                    "term_name": term.term_name,
                    "original_text": term.original_text,
                    "clause_reference": term.clause_reference,
                    "page_number": term.page_number,
                    "interpretation": term.interpretation,
                    "confidence": term.confidence,
                    "effective_date": term.effective_date,
                    "expiry_date": term.expiry_date,
                    "financial_impact": term.financial_impact,
                    "missing_information": term.missing_information,
                    "review_status": term.review_status,
                    "review_notes": term.review_notes,
                    "commercial_details": (
                        {
                            key: value
                            for key, value in vars(
                                commercial_details_by_term[term.id]
                            ).items()
                            if not key.startswith("_")
                        }
                        if term.id in commercial_details_by_term
                        else None
                    ),
                }
                for term in terms
            ],
        }


@app.get("/api/documents/{document_id}/terms/{term_id}")
async def get_contract_term(document_id: str, term_id: int):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractTerm).where(
                ContractTerm.id == term_id,
                ContractTerm.contract_id == document_id,
            )
        )

        term = result.scalar_one_or_none()

        if term is None:
            raise HTTPException(status_code=404, detail="Term not found.")

        chunk_result = await session.execute(
            select(DocumentChunk).where(
                DocumentChunk.id == term.source_chunk_id
            )
        )

        chunk = chunk_result.scalar_one_or_none()

        return {
            "id": term.id,
            "term_category": term.term_category,
            "term_name": term.term_name,
            "original_text": term.original_text,
            "clause_reference": term.clause_reference,
            "page_number": term.page_number,
            "interpretation": term.interpretation,
            "confidence": term.confidence,
            "effective_date": term.effective_date,
            "expiry_date": term.expiry_date,
            "financial_impact": term.financial_impact,
            "missing_information": term.missing_information,
            "review_status": term.review_status,
            "review_notes": term.review_notes,
            "source_evidence": chunk.chunk_text if chunk else None,
        }


@app.patch("/api/documents/{document_id}/terms/{term_id}/review")
async def review_contract_term(
    document_id: str,
    term_id: int,
    review_status: str = Body(...),
    review_notes: Optional[str] = Body(None),
):
    allowed_statuses = {"pending", "approved", "rejected"}

    if review_status not in allowed_statuses:
        raise HTTPException(
            status_code=400,
            detail="Status must be pending, approved or rejected.",
        )

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractTerm).where(
                ContractTerm.id == term_id,
                ContractTerm.contract_id == document_id,
            )
        )

        term = result.scalar_one_or_none()

        if term is None:
            raise HTTPException(status_code=404, detail="Term not found.")

        term.review_status = review_status
        term.review_notes = review_notes
        term.updated_at = datetime.now(timezone.utc)

        await session.commit()
        await session.refresh(term)

        return {
            "message": "Term review updated.",
            "term_id": term.id,
            "review_status": term.review_status,
            "review_notes": term.review_notes,
        }

@app.post("/api/documents/{document_id}/extract-clauses")
async def extract_clauses_endpoint(document_id: str):
    from app.clause_extraction import extract_contract_clauses

    try:
        return await extract_contract_clauses(document_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=repr(e))


@app.get("/api/documents/{document_id}/clauses")
async def get_contract_clauses(document_id: str):
    from app.db_models import ContractClause

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractClause)
            .where(ContractClause.contract_id == document_id)
            .order_by(ContractClause.sequence_number, ContractClause.id)
        )

        clauses = result.scalars().all()

        return [
            {
                "id": clause.id,
                "clause_reference": clause.clause_reference,
                "heading": clause.heading,
                "original_text": clause.original_text,
                "page_start": clause.page_start,
                "page_end": clause.page_end,
                "extraction_status": clause.extraction_status,
                "confidence": clause.confidence,
                "review_status": clause.review_status,
            }
            for clause in clauses
        ]


@app.get("/api/documents/{document_id}/rules")
async def get_contract_rules(document_id: str):
    from app.db_models import ContractRule

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractRule)
            .where(ContractRule.contract_id == document_id)
            .order_by(ContractRule.page_number, ContractRule.id)
        )

        rules = result.scalars().all()

        return [
            {
                "id": rule.id,
                "clause_id": rule.clause_id,
                "rule_type": rule.rule_type,
                "category": rule.category,
                "title": rule.title,
                "actor": rule.actor,
                "beneficiary": rule.beneficiary,
                "modality": rule.modality,
                "action": rule.action,
                "trigger_condition": rule.trigger_condition,
                "deadline_or_duration": rule.deadline_or_duration,
                "amount_or_formula": rule.amount_or_formula,
                "exceptions_or_qualifications": rule.exceptions_or_qualifications,
                "consequence_or_remedy": rule.consequence_or_remedy,
                "cross_references": rule.cross_references,
                "original_text": rule.original_text,
                "plain_language_explanation": rule.plain_language_explanation,
                "contractual_interpretation": rule.contractual_interpretation,
                "uncertainty_or_ambiguity": rule.uncertainty_or_ambiguity,
                "page_number": rule.page_number,
                "confidence": rule.confidence,
                "review_status": rule.review_status,
            }
            for rule in rules
        ]

# Human review endpoints for extracted clauses and rules
from fastapi import Body as ReviewBody

@app.patch("/api/documents/{document_id}/clauses/{clause_id}/review")
async def review_contract_clause(
    document_id: str,
    clause_id: int,
    payload: dict = ReviewBody(...)
):
    from app.db_models import ContractClause
    from datetime import datetime, timezone

    status = payload.get("review_status")
    notes = payload.get("review_notes")

    if status not in {"pending", "reviewed", "resolved"}:
        raise HTTPException(status_code=400, detail="Invalid review status.")

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractClause).where(
                ContractClause.id == clause_id,
                ContractClause.contract_id == document_id
            )
        )
        clause = result.scalar_one_or_none()

        if clause is None:
            raise HTTPException(status_code=404, detail="Clause not found.")

        clause.review_status = status
        clause.review_notes = notes
        clause.updated_at = datetime.now(timezone.utc)
        await session.commit()

        return {
            "id": clause.id,
            "review_status": clause.review_status,
            "review_notes": clause.review_notes
        }


@app.patch("/api/documents/{document_id}/rules/{rule_id}/review")
async def review_contract_rule(
    document_id: str,
    rule_id: int,
    payload: dict = ReviewBody(...)
):
    from app.db_models import ContractRule
    from datetime import datetime, timezone

    status = payload.get("review_status")
    notes = payload.get("review_notes")

    if status not in {"pending", "reviewed", "resolved"}:
        raise HTTPException(status_code=400, detail="Invalid review status.")

    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ContractRule).where(
                ContractRule.id == rule_id,
                ContractRule.contract_id == document_id
            )
        )
        rule = result.scalar_one_or_none()

        if rule is None:
            raise HTTPException(status_code=404, detail="Rule not found.")

        rule.review_status = status
        rule.review_notes = notes
        rule.updated_at = datetime.now(timezone.utc)
        await session.commit()

        return {
            "id": rule.id,
            "review_status": rule.review_status,
            "review_notes": rule.review_notes
        }
